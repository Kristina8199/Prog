const axiosConfig = {
  baseURL: process.env.HOST,
}


module.exports = { axiosConfig }
